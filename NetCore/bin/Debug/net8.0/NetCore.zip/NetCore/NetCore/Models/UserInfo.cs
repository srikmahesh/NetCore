﻿namespace NetCore.Models
{
    public class UserInfo
    {
        public string UserId { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string token { get; set; }
    }
}
